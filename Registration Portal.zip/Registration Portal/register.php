<?php
session_start(); // Start the session
// saving information to .txt file 
if(isset($_POST['submit'])){

	if (empty($_POST["password"])) {

		$password_err = "*Password field empty";
	}

extract($_REQUEST);
$file=fopen("register1.txt","a");


fwrite($file, $firstname . "\n");


fwrite($file, $lastname . "\n");


fwrite($file, $email . "\n");


fwrite($file, $usernamee . "\n");


fwrite($file, $password . "\n");

fwrite($file, $password . "\n");


fclose($file);


	
}
?>

<?php
$cookie_name = "Manga";
$cookie_value = "86400";
setcookie($cookie_name, $cookie_value, time() + (86400 * 1), "/"); // 86400 = 1 day
?>






<!DOCTYPE html>
<html>
<head>
    <title> Registration </title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="style.css" rel="stylesheet" />
</head>


<body>

<?php
if(!isset($_COOKIE[$cookie_name])) {
     echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
     echo "Cookie '" . $cookie_name . "' is set!<br>";
     echo "Value is: " . $_COOKIE[$cookie_name];
}
?>
<div class="container-sm">
		<h2>MANGA WORLD</h2>
		<br />
		<h3>Register</h3>
		<br />
		
		<form method="POST" action="register.php">	
		<div class="form-group row">
				<div class="col-md-4">
					<input type="text" name="firstname" class="form-control" placeholder="Enter Firstname">
					
					<br /><br />
					<input type="text" name="lastname" class="form-control" placeholder="Enter Last Name">
					
				
					<br /><br />
					<input type="text" name="email" class="form-control" placeholder="Enter Email">
					
					
					<br /><br />
					<input type="text" name="usernamee" class="form-control" placeholder="Enter User Name">
					
					

					<br /><br />
					<input type="password" name="password" class="form-control" placeholder="Enter Password">
					
					<br /><br />

					<input type="password" name="password" class="form-control" placeholder="Confirm Password">
					
					<br /><br />

					<input type="submit" class="btn btn-primary btn-lg" name="submit" value="Submit">
					<br /><br />
					<p>Already have an account?<a href="index.php">Login now!</a>.</p>
				</div>
			</div>
		</form>
	</div>
</body>
</html>

